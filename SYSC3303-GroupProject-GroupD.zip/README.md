SYSC3303-GroupProject
=====================

SYSC 3303 Group Project

Game commands

* START_GAME
* END_GAME
* JOIN_GAME
* RESET_LIFE
* UP
* DOWN
* LEFT
* RIGHT
* BOMB

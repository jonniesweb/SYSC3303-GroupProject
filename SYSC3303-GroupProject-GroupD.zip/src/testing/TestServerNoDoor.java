package testing;

import serverLogic.ServerMain;

public class TestServerNoDoor {

	public static void main(String[] args) {
		
		ServerMain server = new ServerMain(false);

	}
}

package testing;

import serverLogic.ServerMain;

public class TestServerWithDoor {

	public static void main(String[] args) {
		new ServerMain(true);
	}
}

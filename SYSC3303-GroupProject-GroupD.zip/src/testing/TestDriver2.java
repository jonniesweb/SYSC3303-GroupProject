package testing;

public class TestDriver2 {
	public static void main(String[] args) {
		new TestDriver("testNumber1.txt",8878);
		new TestDriver("testNumber2.txt",8869);
	}
}
